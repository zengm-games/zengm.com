INSERT INTO "league_conferences" (conference_id,name) VALUES(0,'Eastern Conference');
INSERT INTO "league_conferences" (conference_id,name) VALUES(1,'Western Conference');

INSERT INTO "league_divisions" (division_id,conference_id,name) VALUES(0,0,'Atlantic');
INSERT INTO "league_divisions" (division_id,conference_id,name) VALUES(1,0,'Central');
INSERT INTO "league_divisions" (division_id,conference_id,name) VALUES(2,0,'Southeast');
INSERT INTO "league_divisions" (division_id,conference_id,name) VALUES(3,1,'Southwest');
INSERT INTO "league_divisions" (division_id,conference_id,name) VALUES(4,1,'Northwest');
INSERT INTO "league_divisions" (division_id,conference_id,name) VALUES(5,1,'Pacific');
